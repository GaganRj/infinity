// SearchResultPage.js

const SearchResultPage = ({ query }) => {
  // Fetch or filter data based on the search query
  // You can use the query to filter the data and display the results
  
  return (
    <div>
      <h1>Search Results for: {query}</h1>
      {/* Display the filtered data */}
    </div>
  );
};

export default SearchResultPage;

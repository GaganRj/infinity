import { useState } from 'react';
import './navbar.css'
import { AlignCenter, Filter } from 'lucide-react'
import { Link } from 'react-router-dom';


const NavBar = () => {

  const [showNav, setShowNav] = useState(false);

  const toggleNav = () => {
    setShowNav(!showNav);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="menu-icon" onClick={toggleNav}>
          {/* <AiOutlineMenu /> */}
         <Link to='/'><AlignCenter strokeWidth={2}/></Link> 

        </div>
        {/* <div className={`search-container ${showNav ? 'show' : ''}`}> */}
          <input type="text" placeholder="Search..." className="search-input" />
          {/* <AiOutlineSearch className="search-icon" /> */}
        {/* </div> */}
        <div className="filter-icon">
          <Filter strokeWidth={2}/>
        </div>
      </div>
    </nav>
  )
}

export default NavBar

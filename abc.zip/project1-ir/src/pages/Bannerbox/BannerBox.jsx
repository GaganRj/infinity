import Slider from "react-slick";
import img1 from '../../assets/images/e5d4c155c914e0925ee759f5007db9ad.png'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Style from './bannerbox.module.css'

const BannerBox = () => {

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
    };

    const banner = [
        { id: "1", img: img1 },
        { id: "2", img: img1 },
        { id: "3", img: img1 },
        { id: "4", img: img1 },
        { id: "5", img: img1 },
        { id: "6", img: img1 },

    ]

    const box = [
        { id: "1", content: "Request Anything" },
        { id: "2", content: "Create Events" },
        { id: "3", content: "Action Items" },
    ]

    return (
        <div className={Style.maincontainer}>
            <div className={Style.bxont}>
                {
                    box.map((data) => {
                        return (
                            <div className={Style.boxcontainer} key={data.id}>
                                <center><b>{data.content}</b></center>
                            </div>
                        )
                    })
                }

            </div>
            <div className="slider-container">
                <Slider {...settings}>
                    {
                        banner.map((images) => {
                            return (
                                <div className={Style.slidebox} key={images.id}>
                                <img src={images.img} className={Style.slideImage} alt="Slide" loading="lazy"/>
                            </div>
                            
                            )
                        })
                    }

                </Slider>
            </div>
        </div>
    )
}

export default BannerBox

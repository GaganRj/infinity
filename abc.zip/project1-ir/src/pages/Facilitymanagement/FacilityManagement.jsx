import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Style from './facility.module.css'
import { Link } from 'react-router-dom';

const FacilityManagement = () => {



    const accContent = [
        {
            id: "1",
            question: "Maintainance services",
            link: "",
            answer: [
                { id: "1", title: "Level 3", link:"/facilitymanagement/levelPage" },
                { id: "2", title: "Level 3", link:"/facilityManagement/levelPage" },
                { id: "3", title: "Level 3", link:"/facilityManagement/levelPage" }
            ]
        },
        {
            id: "2",
            question: "Work wear & Uniforms",
            link: "",
            answer: [
                { id: "1", title: "Level 3" },
                { id: "2", title: "Level 3" },
                { id: "3", title: "Level 3" }
            ]
        },
        {
            id: "3",
            question: "Custodial services",
            link: "",
            answer: [
                { id: "1", title: "Level 3" },
                { id: "2", title: "Level 3" },
                { id: "3", title: "Level 3" }
            ]
        },
    ];


    return (
        <div className={Style.maincontainer}>
            {
                accContent ? (
                    accContent.map((list) => {
                        return (
                            <div key={list.id}>
                                <Accordion>
                                    <AccordionSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                    >
                                        <Typography className={Style.headcontent}><b>{list.question}</b></Typography>
                                    </AccordionSummary>
                                    <AccordionDetails>
                                        {
                                            list.answer.map((item) => {
                                                return (
                                                    <Typography className={Style.acccontent} key={item.id}>
                                                        <Link to={item.link}><b>{item.title}</b></Link> 
                                                    </Typography>
                                                )
                                            })
                                        }
                                    </AccordionDetails>

                                </Accordion>
                                <br />
                            </div>
                        )
                    })

                ) : (
                    <p className={Style.admin}>Please wait clientList is updating...</p>
                )
            }

        </div>
    )
}

export default FacilityManagement

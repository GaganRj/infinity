import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepButton from '@mui/material/StepButton';
import Style from './levelpage.module.css'
import { ArrowDownWideNarrow, Search, ChevronsUpDown, ListFilter } from 'lucide-react'
import { product } from "../../Trendingauction/trending";

const LevelPage = () => {
    const navigate = useNavigate();
    const steps = ['Facility Management', 'Maintenance services', 'Level 3'];

    const [activeStep, setActiveStep] = useState(2); // Level 3 is initially active

    const handleStep = (step) => {
        setActiveStep(step);
        // Navigate to corresponding page when step is clicked
        if (step === 0) {
            navigate("/facilityManagement");
        } else if (step === 1) {
            navigate("/facilityManagement");
        }
        // else if (step === 2) {
        //    navigate("/level3");
        // }
    };


    const FiltStep = [
        { id: "1", title: "all" },
        { id: "2", title: "Maintainance service" },
        { id: "3", title: "Work wear & uniform" },
        { id: "4", title: "vew all" },

    ]
    const [selectedFilter, setSelectedFilter] = useState("1"); // Initially select "all"

    const handleFilterClick = (id) => {
        setSelectedFilter(id);
    };
    const [selectedFilter1, setSelectedFilter1] = useState("All");

    const handleFilterClick1 = (filter) => {
        setSelectedFilter1(filter);
    };

    const filteredProducts = selectedFilter1 === "All" ? product : product.filter(item => item.option === selectedFilter1);

    return (
        <div className={Style.maincontainer}>
            <Box sx={{ width: '100%' }}>
                <Stepper nonLinear activeStep={activeStep}>
                    {steps.map((label, index) => (
                        <Step key={label} completed={index < activeStep}>
                            <StepButton color="inherit" onClick={() => handleStep(index)}>
                                {label}
                            </StepButton>
                        </Step>
                    ))}
                </Stepper>
            </Box>
            <br />
            <div className="flex gap-3 overflow-x-auto">
                <div className="flex gap-3 overflow-x-auto">
                    {FiltStep.map((data) => (
                        <div
                            className={`${Style.option} ${selectedFilter === data.id ? Style.selected : ''}`}
                            key={data.id}
                            onClick={() => handleFilterClick(data.id)}
                        >
                            <p>{data.title}</p>
                        </div>
                    ))}
                </div>

            </div>
            <hr />
            <div className="flex justify-between items-center">
                <div className="w-1/4">90,000+ results</div>
                <div className="flex justify-evenly w-3/4">
                    <div><ArrowDownWideNarrow /></div>
                    <div><Search /></div>
                    <div className="flex"><ChevronsUpDown />Sort</div>
                    <div className="flex"><ListFilter />Filter</div>
                </div>
            </div>
            <hr />
            <div className="flex justify-around items-center border-b-2">
                <div
                    className={`${Style.filet3f} ${selectedFilter1 === 'All' ? Style.selected1 : ''}`}
                    onClick={() => handleFilterClick1('All')}
                >
                    <b>All</b>
                </div>
                <div
                    className={`${Style.filet3f} ${selectedFilter1 === 'Auction' ? Style.selected1 : ''}`}
                    onClick={() => handleFilterClick1('Auction')}
                >
                    <b>Auction</b>
                </div>
                <div
                    className={`${Style.filet3f} ${selectedFilter1 === 'Buy it now' ? Style.selected1 : ''}`}
                    onClick={() => handleFilterClick1('Buy it now')}
                >
                    <b>Buy it now</b>
                </div>
            </div>
            <br/>
            <div>
                <div className={Style.rescardcon}>
                    {filteredProducts.map((data) => (
                        <div className={Style.cardcontainer} key={data.id}>
                            <div className={Style.imgcontainer}>
                                <img src={data.img} alt={data.title} />
                            </div>
                            <div className={Style.contentcontainer}>
                                <div className={Style.maintitle}><b>{data.title}</b></div>
                                <div className={Style.price}><b>{data.price}</b></div>
                                <div className={Style.timeleft}>{data.time}</div>
                                <div className={Style.hoursleft}>{data.hours}</div>
                                <div className={Style.timeleft}>{data.birds}</div>
                                <div className={Style.timeleft}>{data.charges}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default LevelPage;

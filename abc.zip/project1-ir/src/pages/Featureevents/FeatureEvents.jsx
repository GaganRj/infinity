import Style from './featureevents.module.css'
import { Users } from 'lucide-react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const FeatureEvents = () => {

    var settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 4,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    initialSlide: 3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 3
                }
            }
        ]
    };

    const cards = [
        { id: "1", },
        { id: "2" },
        { id: "3", },
        { id: "4", },
        { id: "5", },
        { id: "6", },
        { id: "7", },
        { id: "8", },
        { id: "9", },
        { id: "10", }

    ]


    return (
        <div className={Style.maincontainer}>

            {/* HEADER */}
            <div className='flex items-center justify-between'>
                <div className={Style.exploreHead}>Featured Events</div>
                <div className={Style.vill}></div>
            </div>
            <br />
            <div>
                <p className={Style.subtite}>See what`s popular across thousands of Products</p>
            </div>
            <br />

            <Slider {...settings}>
                {
                    cards.map((data) => {
                        return (
                            <div className={Style.cardcontainer} key={data.id}>
                                <div className='flex gap-2'>
                                    <div className={Style.newss}><b>New</b></div>
                                    <div className={Style.newss}><b>Scheduled</b></div>
                                </div>
                                <div className='flex items-center justify-between pt-3'>
                                    <div><b>Requirement of 2000 Diodes at Nasik plant</b></div>
                                    <div>
                                        <div className={Style.month}>Nov</div>
                                        <div><center>18</center></div>
                                    </div>
                                </div>
                                <div className={Style.subtite}>Sat, 02:PM onwards</div>
                                <div className='flex gap-6'>
                                    <div className={Style.imgco}></div>
                                    <div><b>Andrew Smithbr</b><br /><b>Global foundries</b></div>
                                </div>
                                <div className='flex gap-2 pt-2'>
                                    <div><Users color="#1DDDC7" /></div>
                                    <div className={Style.oneonone}>one on one</div>
                                </div>
                            </div>

                        )
                    })
                }

            </Slider>


        </div>
    )
}

export default FeatureEvents

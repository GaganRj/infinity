import { Building } from 'lucide-react'
import { Link } from 'react-router-dom'
import Style from './viewall.module.css'
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom'


const ViewAll = () => {

    const prevLocation = useLocation();

    useEffect(() => {
        window.scrollTo({ left: 0, top: 0, behavior: 'auto' })
    }, [prevLocation])

    const eCategory = [
        { id: "1", title: "Facility Management", icon: <Building />, link: "/facilityManagement" },
        { id: "2", title: "Logistics", icon: <Building />, link: "" },
        { id: "3", title: "Consumer Elctronics", icon: <Building />, link: "" },
        { id: "4", title: "Agricultre", icon: <Building />, link: "" },
        { id: "5", title: "Apparel", icon: <Building />, link: "" },
        { id: "6", title: "Beauy & Personal Care", icon: <Building />, link: "" },
        { id: "7", title: "Business Service", icon: <Building />, link: "" },
        { id: "8", title: "Chemicals", icon: <Building />, link: "" },
        { id: "9", title: "Commercial service", icon: <Building />, link: "" },
        { id: "10", title: "Construction & Real Estate", icon: <Building />, link: "" },
        { id: "11", title: "Electrical Equipment", icon: <Building />, link: "" },
        { id: "12", title: "Electrical Components", icon: <Building />, link: "" },
        { id: "13", title: "Envirnonment", icon: <Building />, link: "" },
        { id: "14", title: "Fabric & Texttile Raw", icon: <Building />, link: "" },
        { id: "15", title: "Fabrication Services", icon: <Building />, link: "" },
        { id: "16", title: "Fashion Accessories", icon: <Building />, link: "" },
        { id: "17", title: "Food & Beverage", icon: <Building />, link: "" },
        { id: "18", title: "Furniture", icon: <Building />, link: "" },
        { id: "19", title: "Gift & Craft", icon: <Building />, link: "" },
        { id: "20", title: "Health & Medical", icon: <Building />, link: "" },
        { id: "21", title: "Home & Garden", icon: <Building />, link: "" },
        { id: "22", title: "Home Application", icon: <Building />, link: "" },
        { id: "23", title: "Home Texttile", icon: <Building />, link: "" },
        { id: "24", title: "Light Lighting", icon: <Building />, link: "" },
        { id: "25", title: "Luggages & Bags", icon: <Building />, link: "" },
        { id: "26", title: "Machinery", icon: <Building />, link: "" },
        { id: "27", title: "Material & Handling", icon: <Building />, link: "" },
        { id: "28", title: "Metal & Alloys", icon: <Building />, link: "" },
        { id: "29", title: "office & school", icon: <Building />, link: "" },
        { id: "30", title: "packaing & Printing", icon: <Building />, link: "" },
        { id: "31", title: "Power Transmission", icon: <Building />, link: "" },
        { id: "32", title: "Renewable Energy", icon: <Building />, link: "" },
      ]
    

  return (
    <div className={Style.maincontainer}>
       {
              eCategory.map((data) => {
                return (
                  <Link to={data.link} key={data.id}>
                    <div className={Style.ecbox}>
                      <div>
                        {data.icon}
                      </div>
                      <div>
                        <b>{data.title}</b>
                      </div>

                    </div>
                  </Link>
                )
              })
            }
    </div>
  )
}

export default ViewAll

import BannerBox from "./Bannerbox/BannerBox"
import EPopularCategory from "./Epopularcategory/EPopularCategory"
import FeatureProSlides from "./Featuredproducts/Featureproslides/FeatureProSlides"
import FeatureEvents from "./Featureevents/FeatureEvents"
import FeatureserSlides from "./Featureservice/Featureserslides/FeatureserSlides"
import TrendingSlides from "./Trendingauction/Trendingslides/TrendingSlides"

const Home = () => {
  return (
    <>
      <BannerBox />
      <EPopularCategory />
      <TrendingSlides />
      <FeatureProSlides />
      <FeatureserSlides />
      <FeatureEvents />
    </>
  )
}

export default Home

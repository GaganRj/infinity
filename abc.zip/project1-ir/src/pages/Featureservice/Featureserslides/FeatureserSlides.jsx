import Style from './serviceslide.module.css'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from 'react-router-dom';
import { product } from '../../Trendingauction/trending';

const FeatureserSlides = () => {

    var settings = {
        dots: false,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 4,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    initialSlide: 3
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 3
                }
            }
        ]
    };

  return (
    <div className={Style.maincontainer}>

    {/* HEADER */}
    <div className='flex items-center justify-between'>
        <div className={Style.exploreHead}>Featured Services</div>
        <div className={Style.vill}></div>
    </div>
    <br />
    <div>
        <p className={Style.subtite}>See what`s popular across thousands of Products</p>
    </div>
    <br />
    {/* SLIDERS */}


    <Slider {...settings}>
        {
            product.map((data) => {
                return (
                    <Link key={data.id}>
                        <div className={Style.cardcontainer}>
                            <div className={Style.imgcontainer}>
                                <img src={data.img} alt='img' loading="lazy"/>
                            </div>
                            <div className={Style.contentcontainer}>
                                <div className={Style.maintitle}><b>{data.title}</b></div>
                                <div className={Style.price}><b>{data.price}</b></div>
                                <div className={Style.timeleft}>{data.time}</div>
                                <div className={Style.hoursleft}>{data.hours}</div>
                                <div className={Style.timeleft}>{data.birds}</div>
                                <div className={Style.timeleft}>{data.charges}</div>
                            </div>
                        </div>
                    </Link>
                )
            })
        }

    </Slider>


</div>
  )
}

export default FeatureserSlides

import { useEffect, useState } from "react";
import NavBar from "./components/Navbar/NavBar"
import ViewAll from "./pages/Epopularcategory/viewall/ViewAll";
import FacilityManagement from "./pages/Facilitymanagement/FacilityManagement";
import Home from "./pages/Home"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {ChevronsUp} from 'lucide-react'
import LevelPage from "./pages/Facilitymanagement/Levelspage/LevelPage";



function App() {

  const [scrollUp, setScrollUp] = useState(false)

  useEffect(() => {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        setScrollUp(true);
      }
      else {
        setScrollUp(false)
      }
    })
  }, [])

  const moveUp = () => {
    window.scrollTo({
      top: 0,
      behavior: "auto"
    })
  }

  return (
    <Router>
      <div>
        <NavBar />
        <Routes>
          <Route path="/" element={<Home />} />
          {/* Add more Route components for other pages */}
          <Route path="/allexpoca" element={<ViewAll />} />
          <Route path="/facilityManagement" element={<FacilityManagement />} />
          <Route path="/facilitymanagement/levelPage" element={<LevelPage />} />


        </Routes>
      </div>
      <div>
          {
            scrollUp && (
              <span
                onClick={moveUp}
                style={{
                  position: "fixed",
                  bottom: "50px",
                  right: "50px",
                  cursor:"pointer"

                }}
              ><ChevronsUp color="#ff9932" size={47} /></span>
            )
          }
        </div>
    </Router>
  )
}

export default App
